package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "doses")
data class DoseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val eyeSide: String, // "right" or "left"
    val timestamp: Long,
    val dropName: String,
    val isDone: Boolean = false,
    val dateIso: String // "YYYY-MM-DD"
)

@Entity(tableName = "schedule_config")
data class ScheduleConfigEntity(
    @PrimaryKey
    val id: Int = 1,
    val targetEye: String = "both", // "both", "right", "left"
    val rightName: String = "",
    val leftName: String = "",
    val rightStartDate: String = "",
    val leftStartDate: String = "",
    val rightStartHour: Int = 8,
    val rightStartMin: Int = 0,
    val rightAmpm: String = "AM",
    val leftStartHour: Int = 8,
    val leftStartMin: Int = 0,
    val leftAmpm: String = "AM",
    val rightInterval: Int = 240, // in minutes
    val leftInterval: Int = 240, // in minutes
    val rightIsCustom: Boolean = false,
    val leftIsCustom: Boolean = false,
    val rightCustomH: Int = 0,
    val rightCustomM: Int = 0,
    val leftCustomH: Int = 0,
    val leftCustomM: Int = 0
)
