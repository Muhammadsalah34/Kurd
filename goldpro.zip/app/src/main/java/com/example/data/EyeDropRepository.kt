package com.example.data

import com.example.util.TimeUtils
import kotlinx.coroutines.flow.Flow

class EyeDropRepository(private val dao: EyeDropDao) {

    val allDoses: Flow<List<DoseEntity>> = dao.getAllDoses()
    val config: Flow<ScheduleConfigEntity?> = dao.getConfig()

    suspend fun saveConfig(config: ScheduleConfigEntity) {
        dao.saveConfig(config)
    }

    suspend fun toggleDose(doseId: Long, currentDone: Boolean) {
        dao.setDoseDone(doseId, !currentDone)
    }

    suspend fun clearSchedule() {
        dao.clearAllDoses()
        dao.clearConfig()
    }

    suspend fun generateAndSaveSchedule(config: ScheduleConfigEntity) {
        val dosesToInsert = mutableListOf<DoseEntity>()

        if (config.targetEye == "right" || config.targetEye == "both") {
            val rightInterval = if (config.rightIsCustom) {
                config.rightCustomH * 60 + config.rightCustomM
            } else {
                config.rightInterval
            }
            val rightDoses = TimeUtils.generateDoses(
                eyeSide = "right",
                dropName = config.rightName.ifBlank { "Right Eye Drop" },
                dateIso = config.rightStartDate,
                hour12 = config.rightStartHour,
                minute = config.rightStartMin,
                ampm = config.rightAmpm,
                intervalMinutes = rightInterval
            )
            dosesToInsert.addAll(rightDoses)
        }

        if (config.targetEye == "left" || config.targetEye == "both") {
            val leftInterval = if (config.leftIsCustom) {
                config.leftCustomH * 60 + config.leftCustomM
            } else {
                config.leftInterval
            }
            val leftDoses = TimeUtils.generateDoses(
                eyeSide = "left",
                dropName = config.leftName.ifBlank { "Left Eye Drop" },
                dateIso = config.leftStartDate,
                hour12 = config.leftStartHour,
                minute = config.leftStartMin,
                ampm = config.leftAmpm,
                intervalMinutes = leftInterval
            )
            dosesToInsert.addAll(leftDoses)
        }

        dao.clearAllDoses()
        dao.saveConfig(config)
        dao.insertDoses(dosesToInsert)
    }
}
