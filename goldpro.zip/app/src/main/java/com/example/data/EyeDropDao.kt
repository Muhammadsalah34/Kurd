package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface EyeDropDao {
    @Query("SELECT * FROM doses ORDER BY timestamp ASC")
    fun getAllDoses(): Flow<List<DoseEntity>>

    @Query("SELECT * FROM doses WHERE eyeSide = :eyeSide ORDER BY timestamp ASC")
    fun getDosesForEye(eyeSide: String): Flow<List<DoseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDoses(doses: List<DoseEntity>)

    @Update
    suspend fun updateDose(dose: DoseEntity)

    @Query("UPDATE doses SET isDone = :isDone WHERE id = :id")
    suspend fun setDoseDone(id: Long, isDone: Boolean)

    @Query("DELETE FROM doses")
    suspend fun clearAllDoses()

    @Query("SELECT * FROM schedule_config WHERE id = 1 LIMIT 1")
    fun getConfig(): Flow<ScheduleConfigEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveConfig(config: ScheduleConfigEntity)

    @Query("DELETE FROM schedule_config")
    suspend fun clearConfig()
}
