package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("eye_drop_prefs", Context.MODE_PRIVATE)

    private val _language = MutableStateFlow(prefs.getString("lang", "ku") ?: "ku")
    val language: StateFlow<String> = _language.asStateFlow()

    private val _isDark = MutableStateFlow(if (prefs.contains("dark_mode")) prefs.getBoolean("dark_mode", false) else null)
    val isDark: StateFlow<Boolean?> = _isDark.asStateFlow()

    private val _clockPosition = MutableStateFlow(prefs.getString("clock_pos", "top") ?: "top")
    val clockPosition: StateFlow<String> = _clockPosition.asStateFlow()

    private val _wallpaperUri = MutableStateFlow(prefs.getString("wallpaper_uri", null))
    val wallpaperUri: StateFlow<String?> = _wallpaperUri.asStateFlow()

    fun setLanguage(lang: String) {
        prefs.edit().putString("lang", lang).apply()
        _language.value = lang
    }

    fun setDarkMode(dark: Boolean?) {
        if (dark == null) {
            prefs.edit().remove("dark_mode").apply()
        } else {
            prefs.edit().putBoolean("dark_mode", dark).apply()
        }
        _isDark.value = dark
    }

    fun setClockPosition(pos: String) {
        prefs.edit().putString("clock_pos", pos).apply()
        _clockPosition.value = pos
    }

    fun setWallpaperUri(uri: String?) {
        if (uri == null) {
            prefs.edit().remove("wallpaper_uri").apply()
        } else {
            prefs.edit().putString("wallpaper_uri", uri).apply()
        }
        _wallpaperUri.value = uri
    }
}
