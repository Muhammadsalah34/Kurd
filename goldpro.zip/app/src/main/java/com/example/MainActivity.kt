package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.EyeDropViewModel
import com.example.ui.MainScreen
import com.example.ui.theme.EyeDropTheme

class MainActivity : ComponentActivity() {
    private val viewModel: EyeDropViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkPref by viewModel.userPreferences.isDark.collectAsStateWithLifecycle()
            val useDark = isDarkPref ?: isSystemInDarkTheme()

            EyeDropTheme(darkTheme = useDark) {
                MainScreen(viewModel = viewModel)
            }
        }
    }
}
