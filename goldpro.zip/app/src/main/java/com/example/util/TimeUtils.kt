package com.example.util

import com.example.data.DoseEntity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object TimeUtils {

    fun todayIso(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    fun dateToIso(cal: Calendar): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(cal.time)
    }

    fun formatTime12(timestamp: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = timestamp }
        val hour24 = cal.get(Calendar.HOUR_OF_DAY)
        val min = cal.get(Calendar.MINUTE)
        val ampm = if (hour24 >= 12) "PM" else "AM"
        val hour12 = when (val h = hour24 % 12) {
            0 -> 12
            else -> h
        }
        val minStr = if (min < 10) "0$min" else "$min"
        val hourStr = if (hour12 < 10) "0$hour12" else "$hour12"
        return "$ampm $hourStr:$minStr"
    }

    fun formatDuration(totalSeconds: Long): String {
        val sec = (totalSeconds % 60).coerceAtLeast(0)
        val min = ((totalSeconds / 60) % 60).coerceAtLeast(0)
        val hours = (totalSeconds / 3600).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d:%02d", hours, min, sec)
    }

    fun getDayDateStr(startDateIso: String, dayOffset: Int): Pair<String, Pair<Int, Int>> {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()
        try {
            val d = sdf.parse(startDateIso)
            if (d != null) cal.time = d
        } catch (_: Exception) {}
        cal.add(Calendar.DAY_OF_YEAR, dayOffset)
        val iso = sdf.format(cal.time)
        val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
        val month = cal.get(Calendar.MONTH) + 1
        return Pair(iso, Pair(dayOfMonth, month))
    }

    fun getDayOfWeekIndex(dateIso: String): Int {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()
        try {
            val d = sdf.parse(dateIso)
            if (d != null) cal.time = d
        } catch (_: Exception) {}
        // Calendar.SUNDAY is 1 -> map to 0 (Sunday) to 6 (Saturday)
        return (cal.get(Calendar.DAY_OF_WEEK) - 1).coerceIn(0, 6)
    }

    fun to24Hour(hour12: Int, minute: Int, ampm: String): Pair<Int, Int> {
        var h = hour12
        if (ampm.equals("PM", ignoreCase = true) && h < 12) h += 12
        if (ampm.equals("AM", ignoreCase = true) && h == 12) h = 0
        return Pair(h, minute)
    }

    fun generateDoses(
        eyeSide: String,
        dropName: String,
        dateIso: String,
        hour12: Int,
        minute: Int,
        ampm: String,
        intervalMinutes: Int
    ): List<DoseEntity> {
        if (intervalMinutes <= 0) return emptyList()

        val (h24, m) = to24Hour(hour12, minute, ampm)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)

        val cal = Calendar.getInstance()
        try {
            val parsedDate = sdf.parse(dateIso)
            if (parsedDate != null) cal.time = parsedDate
        } catch (_: Exception) {}

        // Set to start time
        cal.set(Calendar.HOUR_OF_DAY, h24)
        cal.set(Calendar.MINUTE, m)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val baseStart = cal.timeInMillis

        // Day boundary (00:00:00) of start date
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val dayStartBoundary = cal.timeInMillis

        val intervalMs = intervalMinutes.toLong() * 60_000L
        var firstDose = baseStart
        while (firstDose - intervalMs >= dayStartBoundary) {
            firstDose -= intervalMs
        }

        val totalMinutes = 7L * 24L * 60L
        val maxTime = baseStart + totalMinutes * 60_000L

        val result = mutableListOf<DoseEntity>()
        var current = firstDose
        val isoFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)

        while (current <= maxTime) {
            if (current >= dayStartBoundary) {
                val doseDateIso = isoFormatter.format(Date(current))
                result.add(
                    DoseEntity(
                        eyeSide = eyeSide,
                        timestamp = current,
                        dropName = dropName,
                        isDone = false,
                        dateIso = doseDateIso
                    )
                )
            }
            current += intervalMs
        }
        return result
    }

    fun formatIntervalBadge(intervalMinutes: Int, lang: String): String {
        val i18n = I18nManager.getStrings(lang)
        val key = intervalMinutes.toString()
        if (i18n.intervals.containsKey(key)) {
            return i18n.intervals[key] ?: ""
        }
        val h = intervalMinutes / 60
        val m = intervalMinutes % 60
        val hUnit = when (lang) {
            "en" -> "hrs"
            "ar" -> "ساعات"
            "fa" -> "ساعت"
            else -> "کاتژمێر"
        }
        val mUnit = when (lang) {
            "en" -> "mins"
            "ar" -> "دقيقة"
            "fa" -> "دقیقه"
            else -> "دەقە"
        }
        val sb = StringBuilder()
        if (h > 0) sb.append("$h $hUnit")
        if (m > 0) {
            if (sb.isNotEmpty()) sb.append(" ")
            sb.append("$m $mUnit")
        }
        return if (sb.isNotEmpty()) sb.toString() else "$intervalMinutes mins"
    }
}
