package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.DoseEntity
import java.io.File
import java.io.FileOutputStream

object PdfExporter {

    fun exportScheduleToPdf(
        context: Context,
        eyeSide: String,
        dropName: String,
        intervalMinutes: Int,
        doses: List<DoseEntity>,
        lang: String
    ) {
        val i18n = I18nManager.getStrings(lang)
        val eyeLabel = if (eyeSide == "right") i18n.rightEyeLabel else i18n.leftEyeLabel
        val intervalText = TimeUtils.formatIntervalBadge(intervalMinutes, lang)

        val document = PdfDocument()
        val pageWidth = 595 // Standard A4 width at 72dpi
        val pageHeight = 842 // Standard A4 height at 72dpi
        var pageNumber = 1

        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas

        val headerPaint = Paint().apply {
            color = Color.parseColor("#1B4D3E")
            isAntiAlias = true
        }
        val textPaint = Paint().apply {
            color = Color.parseColor("#111B15")
            textSize = 12f
            isAntiAlias = true
        }
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            isFakeBoldText = true
            isAntiAlias = true
        }
        val subPaint = Paint().apply {
            color = Color.parseColor("#E4EEE7")
            textSize = 11f
            isAntiAlias = true
        }
        val linePaint = Paint().apply {
            color = Color.parseColor("#CCCCCC")
            strokeWidth = 1f
            isAntiAlias = true
        }
        val tableHeadPaint = Paint().apply {
            color = Color.parseColor("#E4EEE7")
            isAntiAlias = true
        }
        val tableHeadTextPaint = Paint().apply {
            color = Color.parseColor("#1B4D3E")
            textSize = 11f
            isFakeBoldText = true
            isAntiAlias = true
        }

        // Header rectangle
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 75f, headerPaint)
        canvas.drawText("${i18n.title} - $eyeLabel", 25f, 35f, titlePaint)
        canvas.drawText("$dropName | ${i18n.intervalLabelText} $intervalText", 25f, 58f, subPaint)

        var y = 100f

        // Table Header
        canvas.drawRect(25f, y, pageWidth - 25f, y + 24f, tableHeadPaint)
        canvas.drawText(i18n.date, 35f, y + 16f, tableHeadTextPaint)
        canvas.drawText(i18n.timeCol, 150f, y + 16f, tableHeadTextPaint)
        canvas.drawText(i18n.doseCol, 260f, y + 16f, tableHeadTextPaint)
        canvas.drawText(i18n.statusCol, 440f, y + 16f, tableHeadTextPaint)
        y += 24f

        val sortedDoses = doses.sortedBy { it.timestamp }

        for (dose in sortedDoses) {
            if (y > pageHeight - 60f) {
                // Draw footer for current page
                drawFooter(canvas, pageWidth, pageHeight, pageNumber, i18n.footer)
                document.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = 40f
            }

            canvas.drawLine(25f, y, pageWidth - 25f, y, linePaint)
            y += 18f

            val timeStr = TimeUtils.formatTime12(dose.timestamp)
            val dayOfWeekIndex = TimeUtils.getDayOfWeekIndex(dose.dateIso)
            val dayName = i18n.days.getOrElse(dayOfWeekIndex) { "" }
            val statusStr = if (dose.isDone) "✓ ${i18n.done}" else "○ ${i18n.mark}"

            canvas.drawText("${dose.dateIso} ($dayName)", 35f, y, textPaint)
            canvas.drawText(timeStr, 150f, y, textPaint)
            canvas.drawText(dose.dropName, 260f, y, textPaint)
            canvas.drawText(statusStr, 440f, y, textPaint)
            y += 8f
        }

        drawFooter(canvas, pageWidth, pageHeight, pageNumber, i18n.footer)
        document.finishPage(page)

        try {
            val cacheDir = File(context.cacheDir, "pdf_schedules").apply { mkdirs() }
            val safeName = dropName.replace("[^a-zA-Z0-9_-]".toRegex(), "_").ifEmpty { eyeSide }
            val pdfFile = File(cacheDir, "EyeDrop_${eyeSide}_$safeName.pdf")
            val outputStream = FileOutputStream(pdfFile)
            document.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            document.close()

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "${i18n.title} - $eyeLabel")
                putExtra(Intent.EXTRA_TEXT, "$dropName - $intervalText")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "${i18n.exportPdf} - $eyeLabel"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun drawFooter(canvas: android.graphics.Canvas, width: Int, height: Int, pageNum: Int, footerText: String) {
        val paint = Paint().apply {
            color = Color.GRAY
            textSize = 10f
            isAntiAlias = true
        }
        val y = height - 25f
        canvas.drawText(footerText, 25f, y, paint)
        canvas.drawText("Page $pageNum", width - 75f, y, paint)
    }
}
