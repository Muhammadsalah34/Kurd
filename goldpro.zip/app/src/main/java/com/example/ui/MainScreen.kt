package com.example.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.ui.components.DrawerContent
import com.example.ui.components.EyeSetupCard
import com.example.ui.components.HeroCountdownCard
import com.example.ui.components.SocialMediaLinkItem
import com.example.ui.components.WeeklyScheduleView
import com.example.util.I18nManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: EyeDropViewModel) {
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = androidx.compose.material3.DrawerValue.Closed)
    val snackbarHostState = remember { SnackbarHostState() }

    val lang by viewModel.userPreferences.language.collectAsStateWithLifecycle()
    val isDarkPref by viewModel.userPreferences.isDark.collectAsStateWithLifecycle()
    val clockPos by viewModel.userPreferences.clockPosition.collectAsStateWithLifecycle()
    val wallpaperUriStr by viewModel.userPreferences.wallpaperUri.collectAsStateWithLifecycle()

    val currentTimeMs by viewModel.currentTimeMs.collectAsStateWithLifecycle()
    val allDoses by viewModel.allDoses.collectAsStateWithLifecycle()
    val config by viewModel.config.collectAsStateWithLifecycle()
    val selectedPage by viewModel.selectedPage.collectAsStateWithLifecycle()

    val rightSelectedDay by viewModel.rightSelectedDay.collectAsStateWithLifecycle()
    val leftSelectedDay by viewModel.leftSelectedDay.collectAsStateWithLifecycle()
    val rightCollapsed by viewModel.rightCollapsed.collectAsStateWithLifecycle()
    val leftCollapsed by viewModel.leftCollapsed.collectAsStateWithLifecycle()

    val targetEye by viewModel.targetEye.collectAsStateWithLifecycle()
    val rightName by viewModel.rightDropName.collectAsStateWithLifecycle()
    val rightStartHour by viewModel.rightStartHour.collectAsStateWithLifecycle()
    val rightStartMin by viewModel.rightStartMin.collectAsStateWithLifecycle()
    val rightAmpm by viewModel.rightAmpm.collectAsStateWithLifecycle()
    val rightStartDate by viewModel.rightStartDate.collectAsStateWithLifecycle()
    val rightInterval by viewModel.rightInterval.collectAsStateWithLifecycle()
    val rightIsCustom by viewModel.rightIsCustom.collectAsStateWithLifecycle()
    val rightCustomH by viewModel.rightCustomHours.collectAsStateWithLifecycle()
    val rightCustomM by viewModel.rightCustomMins.collectAsStateWithLifecycle()

    val leftName by viewModel.leftDropName.collectAsStateWithLifecycle()
    val leftStartHour by viewModel.leftStartHour.collectAsStateWithLifecycle()
    val leftStartMin by viewModel.leftStartMin.collectAsStateWithLifecycle()
    val leftAmpm by viewModel.leftAmpm.collectAsStateWithLifecycle()
    val leftStartDate by viewModel.leftStartDate.collectAsStateWithLifecycle()
    val leftInterval by viewModel.leftInterval.collectAsStateWithLifecycle()
    val leftIsCustom by viewModel.leftIsCustom.collectAsStateWithLifecycle()
    val leftCustomH by viewModel.leftCustomHours.collectAsStateWithLifecycle()
    val leftCustomM by viewModel.leftCustomMins.collectAsStateWithLifecycle()

    val feedbackMessage by viewModel.userFeedbackMessage.collectAsStateWithLifecycle()

    val i18n = I18nManager.getStrings(lang)
    val isRtl = I18nManager.isRtl(lang)
    val layoutDirection = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    var showClearDialog by remember { mutableStateOf(false) }

    LaunchedEffect(feedbackMessage) {
        feedbackMessage?.let { msg ->
            val text = when (msg) {
                "SAVED" -> i18n.saved
                "CLEARED" -> i18n.clear
                else -> msg
            }
            snackbarHostState.showSnackbar(text)
            viewModel.clearFeedbackMessage()
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text(i18n.clear) },
            text = { Text(i18n.clearConfirm) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAll()
                        showClearDialog = false
                    }
                ) {
                    Text(i18n.clear, color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text(i18n.done)
                }
            }
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet {
                    DrawerContent(
                        currentTimeMs = currentTimeMs,
                        lang = lang,
                        onLanguageChange = { newLang ->
                            viewModel.userPreferences.setLanguage(newLang)
                        },
                        isDark = isDarkPref ?: false,
                        onToggleDark = {
                            viewModel.userPreferences.setDarkMode(!(isDarkPref ?: false))
                        },
                        clockPosition = clockPos,
                        onMoveClock = { newPos ->
                            viewModel.userPreferences.setClockPosition(newPos)
                        },
                        onNavigate = { page ->
                            viewModel.setSelectedPage(page)
                        },
                        onWallpaperSelected = { uri ->
                            viewModel.userPreferences.setWallpaperUri(uri?.toString())
                        },
                        onClose = {
                            scope.launch { drawerState.close() }
                        }
                    )
                }
            }
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Custom Wallpaper Layer if selected
                if (!wallpaperUriStr.isNullOrEmpty()) {
                    AsyncImage(
                        model = Uri.parse(wallpaperUriStr),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    // Translucent overlay over wallpaper
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.85f))
                    )
                }

                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    containerColor = if (!wallpaperUriStr.isNullOrEmpty()) Color.Transparent else MaterialTheme.colorScheme.background,
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.primary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.WaterDrop,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = i18n.title,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = i18n.subtitle,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            },
                            navigationIcon = {
                                IconButton(
                                    onClick = { scope.launch { drawerState.open() } },
                                    modifier = Modifier.testTag("menu_hamburger_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Menu,
                                        contentDescription = i18n.menuTitle,
                                        tint = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            },
                            actions = {
                                // Theme toggle button
                                IconButton(
                                    onClick = {
                                        viewModel.userPreferences.setDarkMode(!(isDarkPref ?: false))
                                    },
                                    modifier = Modifier.testTag("topbar_theme_btn")
                                ) {
                                    Icon(
                                        imageVector = if (isDarkPref == true) Icons.Default.LightMode else Icons.Default.DarkMode,
                                        contentDescription = i18n.mThemeToggleText,
                                        tint = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                // Language Selector Quick Menu
                                var langMenuExpanded by remember { mutableStateOf(false) }
                                Box {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                        modifier = Modifier
                                            .clickable { langMenuExpanded = true }
                                            .padding(end = 8.dp)
                                            .testTag("topbar_lang_btn")
                                    ) {
                                        Text(
                                            text = when (lang) {
                                                "ar" -> "العربية"
                                                "en" -> "English"
                                                "fa" -> "فارسی"
                                                else -> "کوردی"
                                            },
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                        )
                                    }

                                    DropdownMenu(
                                        expanded = langMenuExpanded,
                                        onDismissRequest = { langMenuExpanded = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("کوردی") },
                                            onClick = {
                                                viewModel.userPreferences.setLanguage("ku")
                                                langMenuExpanded = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("العربية") },
                                            onClick = {
                                                viewModel.userPreferences.setLanguage("ar")
                                                langMenuExpanded = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("English") },
                                            onClick = {
                                                viewModel.userPreferences.setLanguage("en")
                                                langMenuExpanded = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("فارسی") },
                                            onClick = {
                                                viewModel.userPreferences.setLanguage("fa")
                                                langMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
                            )
                        )
                    }
                ) { innerPadding ->
                    val scrollState = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .verticalScroll(scrollState)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .widthIn(max = 600.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Page Switcher Bar (Tabs)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val isMainSelected = selectedPage == 0
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (isMainSelected) MaterialTheme.colorScheme.primary
                                            else Color.Transparent
                                        )
                                        .clickable { viewModel.setSelectedPage(0) }
                                        .padding(vertical = 8.dp)
                                        .testTag("page_tab_main"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = i18n.tabMainText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isMainSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                val isSchedSelected = selectedPage == 1
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (isSchedSelected) MaterialTheme.colorScheme.primary
                                            else Color.Transparent
                                        )
                                        .clickable { viewModel.setSelectedPage(1) }
                                        .padding(vertical = 8.dp)
                                        .testTag("page_tab_schedules"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = i18n.tabSchedulesText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSchedSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        // PAGE 0: Control & Clock & Setup
                        if (selectedPage == 0) {
                            // Hero Countdown Cards
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                val currentTarget = targetEye
                                if (currentTarget == "right" || currentTarget == "both") {
                                    HeroCountdownCard(
                                        eyeSide = "right",
                                        eyeLabel = i18n.rightEyeLabel,
                                        doses = allDoses,
                                        currentTimeMs = currentTimeMs,
                                        lang = lang,
                                        onClick = {
                                            viewModel.targetEye.value = "right"
                                        }
                                    )
                                }
                                if (currentTarget == "left" || currentTarget == "both") {
                                    HeroCountdownCard(
                                        eyeSide = "left",
                                        eyeLabel = i18n.leftEyeLabel,
                                        doses = allDoses,
                                        currentTimeMs = currentTimeMs,
                                        lang = lang,
                                        onClick = {
                                            viewModel.targetEye.value = "left"
                                        }
                                    )
                                }
                            }

                            // Setup Form Section
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                modifier = Modifier.fillMaxWidth().testTag("setup_form_card")
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = i18n.setup,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )

                                    // Target Eye Selector Dropdown
                                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(
                                            text = i18n.targetEyeLbl,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )

                                        var targetDropdownExpanded by remember { mutableStateOf(false) }
                                        val targetLabel = when (targetEye) {
                                            "right" -> i18n.rightOnlyOpt
                                            "left" -> i18n.leftOnlyOpt
                                            else -> i18n.bothOpt
                                        }

                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(MaterialTheme.colorScheme.surface)
                                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                                                .clickable { targetDropdownExpanded = true }
                                                .padding(horizontal = 10.dp, vertical = 9.dp)
                                                .testTag("target_eye_selector"),
                                            contentAlignment = Alignment.CenterStart
                                        ) {
                                            Text(targetLabel, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)

                                            DropdownMenu(
                                                expanded = targetDropdownExpanded,
                                                onDismissRequest = { targetDropdownExpanded = false }
                                            ) {
                                                DropdownMenuItem(
                                                    text = { Text(i18n.bothOpt, fontSize = 11.sp) },
                                                    onClick = {
                                                        viewModel.targetEye.value = "both"
                                                        targetDropdownExpanded = false
                                                    }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text(i18n.rightOnlyOpt, fontSize = 11.sp) },
                                                    onClick = {
                                                        viewModel.targetEye.value = "right"
                                                        targetDropdownExpanded = false
                                                    }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text(i18n.leftOnlyOpt, fontSize = 11.sp) },
                                                    onClick = {
                                                        viewModel.targetEye.value = "left"
                                                        targetDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Right Eye Configuration Card
                                    if (targetEye == "right" || targetEye == "both") {
                                        EyeSetupCard(
                                            eyeSide = "right",
                                            eyeTitle = i18n.rightEyeLabel,
                                            dropName = rightName,
                                            onDropNameChange = { viewModel.rightDropName.value = it },
                                            dropNamePlaceholder = i18n.rightNamePh,
                                            startHour = rightStartHour,
                                            onStartHourChange = { viewModel.rightStartHour.value = it },
                                            startMin = rightStartMin,
                                            onStartMinChange = { viewModel.rightStartMin.value = it },
                                            ampm = rightAmpm,
                                            onAmpmChange = { viewModel.rightAmpm.value = it },
                                            startDate = rightStartDate,
                                            onStartDateChange = { viewModel.rightStartDate.value = it },
                                            intervalMinutes = rightInterval,
                                            onIntervalChange = { viewModel.rightInterval.value = it },
                                            isCustomInterval = rightIsCustom,
                                            onIsCustomChange = { viewModel.rightIsCustom.value = it },
                                            customHours = rightCustomH,
                                            onCustomHoursChange = { viewModel.rightCustomHours.value = it },
                                            customMinutes = rightCustomM,
                                            onCustomMinutesChange = { viewModel.rightCustomMins.value = it },
                                            lang = lang
                                        )
                                    }

                                    // Left Eye Configuration Card
                                    if (targetEye == "left" || targetEye == "both") {
                                        EyeSetupCard(
                                            eyeSide = "left",
                                            eyeTitle = i18n.leftEyeLabel,
                                            dropName = leftName,
                                            onDropNameChange = { viewModel.leftDropName.value = it },
                                            dropNamePlaceholder = i18n.leftNamePh,
                                            startHour = leftStartHour,
                                            onStartHourChange = { viewModel.leftStartHour.value = it },
                                            startMin = leftStartMin,
                                            onStartMinChange = { viewModel.leftStartMin.value = it },
                                            ampm = leftAmpm,
                                            onAmpmChange = { viewModel.leftAmpm.value = it },
                                            startDate = leftStartDate,
                                            onStartDateChange = { viewModel.leftStartDate.value = it },
                                            intervalMinutes = leftInterval,
                                            onIntervalChange = { viewModel.leftInterval.value = it },
                                            isCustomInterval = leftIsCustom,
                                            onIsCustomChange = { viewModel.leftIsCustom.value = it },
                                            customHours = leftCustomH,
                                            onCustomHoursChange = { viewModel.leftCustomHours.value = it },
                                            customMinutes = leftCustomM,
                                            onCustomMinutesChange = { viewModel.leftCustomMins.value = it },
                                            lang = lang
                                        )
                                    }

                                    // Fill With Today Button
                                    OutlinedButton(
                                        onClick = { viewModel.fillWithToday() },
                                        modifier = Modifier.fillMaxWidth().testTag("fill_today_btn"),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(i18n.todayBtn, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    }

                                    // Generate Schedule Button
                                    Button(
                                        onClick = {
                                            viewModel.generateSchedule(
                                                fallbackRightName = i18n.rightEyeLabel,
                                                fallbackLeftName = i18n.leftEyeLabel
                                            )
                                        },
                                        modifier = Modifier.fillMaxWidth().testTag("generate_schedule_btn"),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                    ) {
                                        Text(
                                            text = i18n.generate,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }

                        // PAGE 1: Weekly Schedules
                        if (selectedPage == 1) {
                            WeeklyScheduleView(
                                config = config,
                                doses = allDoses,
                                rightSelectedDay = rightSelectedDay,
                                onRightDaySelect = { viewModel.setRightSelectedDay(it) },
                                leftSelectedDay = leftSelectedDay,
                                onLeftDaySelect = { viewModel.setLeftSelectedDay(it) },
                                rightCollapsed = rightCollapsed,
                                onToggleRightCollapse = { viewModel.toggleRightCollapse() },
                                leftCollapsed = leftCollapsed,
                                onToggleLeftCollapse = { viewModel.toggleLeftCollapse() },
                                onToggleDose = { viewModel.toggleDose(it) },
                                onSave = { viewModel.saveCurrent() },
                                onClear = { showClearDialog = true },
                                lang = lang
                            )
                        }

                        // Bottom Social Media Card
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = i18n.socialTitle,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                SocialMediaLinkItem(
                                    label = i18n.mYoutube,
                                    url = "https://youtube.com/@kurdroid_official?si=VofAoHfJnhub_qn3",
                                    badgeColor = Color(0xFFFF0000)
                                )
                                SocialMediaLinkItem(
                                    label = i18n.mFacebook,
                                    url = "https://www.facebook.com/share/1EgyH2z5bA/",
                                    badgeColor = Color(0xFF1877F2)
                                )
                                SocialMediaLinkItem(
                                    label = i18n.mTelegram,
                                    url = "https://t.me/kurdroid_official",
                                    badgeColor = Color(0xFF229ED9)
                                )
                                SocialMediaLinkItem(
                                    label = i18n.mTiktok,
                                    url = "https://tiktok.com/@designstudio2026",
                                    badgeColor = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        // Footer Credits
                        Text(
                            text = i18n.footer,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}
