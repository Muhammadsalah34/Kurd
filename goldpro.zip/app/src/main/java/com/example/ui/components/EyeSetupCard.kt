package com.example.ui.components

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.I18nManager
import java.util.Calendar

@Composable
fun EyeSetupCard(
    eyeSide: String, // "right" or "left"
    eyeTitle: String,
    dropName: String,
    onDropNameChange: (String) -> Unit,
    dropNamePlaceholder: String,
    startHour: Int,
    onStartHourChange: (Int) -> Unit,
    startMin: Int,
    onStartMinChange: (Int) -> Unit,
    ampm: String,
    onAmpmChange: (String) -> Unit,
    startDate: String,
    onStartDateChange: (String) -> Unit,
    intervalMinutes: Int,
    onIntervalChange: (Int) -> Unit,
    isCustomInterval: Boolean,
    onIsCustomChange: (Boolean) -> Unit,
    customHours: Int,
    onCustomHoursChange: (Int) -> Unit,
    customMinutes: Int,
    onCustomMinutesChange: (Int) -> Unit,
    lang: String,
    modifier: Modifier = Modifier
) {
    val i18n = I18nManager.getStrings(lang)
    val context = LocalContext.current

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Card Title
            Text(
                text = "👁️ $eyeTitle",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Drop Name
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = if (eyeSide == "right") i18n.rightName else i18n.leftName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                OutlinedTextField(
                    value = dropName,
                    onValueChange = onDropNameChange,
                    placeholder = { Text(dropNamePlaceholder, fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth().testTag("${eyeSide}_drop_name_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp)
                )
            }

            // Start Time (Hour & Minute)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "${i18n.start} (${i18n.hPH} & ${i18n.mPH})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = if (startHour == 0) "" else startHour.toString(),
                        onValueChange = {
                            val v = it.filter { char -> char.isDigit() }.toIntOrNull()
                            if (v != null) onStartHourChange(v.coerceIn(1, 12))
                            else if (it.isEmpty()) onStartHourChange(0)
                        },
                        placeholder = { Text("1-12", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("${eyeSide}_start_hour_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    OutlinedTextField(
                        value = if (startMin < 10) "0$startMin" else startMin.toString(),
                        onValueChange = {
                            val v = it.filter { char -> char.isDigit() }.toIntOrNull()
                            if (v != null) onStartMinChange(v.coerceIn(0, 59))
                            else if (it.isEmpty()) onStartMinChange(0)
                        },
                        placeholder = { Text("0-59", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("${eyeSide}_start_min_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            // AM / PM Selector
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = i18n.ampmLbl,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val isAm = ampm.equals("AM", ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isAm) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                            .clickable { onAmpmChange("AM") }
                            .padding(vertical = 8.dp)
                            .testTag("${eyeSide}_am_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = i18n.amOpt,
                            color = if (isAm) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (!isAm) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                            .clickable { onAmpmChange("PM") }
                            .padding(vertical = 8.dp)
                            .testTag("${eyeSide}_pm_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = i18n.pmOpt,
                            color = if (!isAm) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Start Date Picker Button
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = i18n.date,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                        .clickable {
                            val cal = Calendar.getInstance()
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val formatted = String.format(java.util.Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                                    onStartDateChange(formatted)
                                },
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH),
                                cal.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }
                        .padding(horizontal = 10.dp, vertical = 9.dp)
                        .testTag("${eyeSide}_date_picker"),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = startDate,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium
                        )
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = i18n.date,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Interval selector
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = i18n.interval,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                var intervalDropdownExpanded by remember { mutableStateOf(false) }
                val intervalOptions = listOf(
                    180 to (i18n.intervals["180"] ?: "3 Hours"),
                    210 to (i18n.intervals["210"] ?: "3.5 Hours"),
                    240 to (i18n.intervals["240"] ?: "4 Hours"),
                    360 to (i18n.intervals["360"] ?: "6 Hours"),
                    540 to (i18n.intervals["540"] ?: "9 Hours"),
                    720 to (i18n.intervals["720"] ?: "12 Hours")
                )

                val currentLabel = if (isCustomInterval) {
                    i18n.customOpt
                } else {
                    i18n.intervals[intervalMinutes.toString()] ?: "$intervalMinutes mins"
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                        .clickable { intervalDropdownExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 10.dp)
                        .testTag("${eyeSide}_interval_dropdown"),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = currentLabel,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    DropdownMenu(
                        expanded = intervalDropdownExpanded,
                        onDismissRequest = { intervalDropdownExpanded = false }
                    ) {
                        intervalOptions.forEach { (mins, label) ->
                            DropdownMenuItem(
                                text = { Text(label, fontSize = 12.sp) },
                                onClick = {
                                    onIsCustomChange(false)
                                    onIntervalChange(mins)
                                    intervalDropdownExpanded = false
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(i18n.customOpt, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                            onClick = {
                                onIsCustomChange(true)
                                intervalDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            // Custom Hours & Mins input if custom chosen
            if (isCustomInterval) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = i18n.customLbl,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedTextField(
                            value = if (customHours == 0) "" else customHours.toString(),
                            onValueChange = {
                                val v = it.filter { char -> char.isDigit() }.toIntOrNull()
                                if (v != null) onCustomHoursChange(v.coerceIn(0, 23))
                                else if (it.isEmpty()) onCustomHoursChange(0)
                            },
                            placeholder = { Text(i18n.hPH, fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("${eyeSide}_custom_h_input"),
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )
                        OutlinedTextField(
                            value = if (customMinutes == 0) "" else customMinutes.toString(),
                            onValueChange = {
                                val v = it.filter { char -> char.isDigit() }.toIntOrNull()
                                if (v != null) onCustomMinutesChange(v.coerceIn(0, 59))
                                else if (it.isEmpty()) onCustomMinutesChange(0)
                            },
                            placeholder = { Text(i18n.mPH, fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("${eyeSide}_custom_m_input"),
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }
            }
        }
    }
}
