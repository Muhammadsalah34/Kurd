package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.DoseEntity
import com.example.data.EyeDropRepository
import com.example.data.ScheduleConfigEntity
import com.example.data.UserPreferences
import com.example.util.TimeUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class EyeDropViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = EyeDropRepository(db.eyeDropDao())
    val userPreferences = UserPreferences(application)

    val allDoses: StateFlow<List<DoseEntity>> = repository.allDoses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val config: StateFlow<ScheduleConfigEntity?> = repository.config
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Current time ticker (ticks every 1000ms)
    private val _currentTimeMs = MutableStateFlow(System.currentTimeMillis())
    val currentTimeMs: StateFlow<Long> = _currentTimeMs.asStateFlow()

    // Page state: 0 = Control & Clock, 1 = Weekly Schedules
    private val _selectedPage = MutableStateFlow(0)
    val selectedPage: StateFlow<Int> = _selectedPage.asStateFlow()

    // Day selection tabs
    private val _rightSelectedDay = MutableStateFlow(0)
    val rightSelectedDay: StateFlow<Int> = _rightSelectedDay.asStateFlow()

    private val _leftSelectedDay = MutableStateFlow(0)
    val leftSelectedDay: StateFlow<Int> = _leftSelectedDay.asStateFlow()

    // Collapse state
    private val _rightCollapsed = MutableStateFlow(false)
    val rightCollapsed: StateFlow<Boolean> = _rightCollapsed.asStateFlow()

    private val _leftCollapsed = MutableStateFlow(false)
    val leftCollapsed: StateFlow<Boolean> = _leftCollapsed.asStateFlow()

    // Setup form inputs
    val targetEye = MutableStateFlow("both") // "both", "right", "left"

    val rightDropName = MutableStateFlow("")
    val rightStartHour = MutableStateFlow(8)
    val rightStartMin = MutableStateFlow(0)
    val rightAmpm = MutableStateFlow("AM")
    val rightStartDate = MutableStateFlow(TimeUtils.todayIso())
    val rightInterval = MutableStateFlow(240) // minutes
    val rightIsCustom = MutableStateFlow(false)
    val rightCustomHours = MutableStateFlow(4)
    val rightCustomMins = MutableStateFlow(0)

    val leftDropName = MutableStateFlow("")
    val leftStartHour = MutableStateFlow(8)
    val leftStartMin = MutableStateFlow(0)
    val leftAmpm = MutableStateFlow("AM")
    val leftStartDate = MutableStateFlow(TimeUtils.todayIso())
    val leftInterval = MutableStateFlow(240) // minutes
    val leftIsCustom = MutableStateFlow(false)
    val leftCustomHours = MutableStateFlow(4)
    val leftCustomMins = MutableStateFlow(0)

    private val _userFeedbackMessage = MutableStateFlow<String?>(null)
    val userFeedbackMessage: StateFlow<String?> = _userFeedbackMessage.asStateFlow()

    init {
        // Start live ticker
        viewModelScope.launch {
            while (true) {
                _currentTimeMs.value = System.currentTimeMillis()
                delay(1000)
            }
        }

        // Set initial today values
        fillWithToday()

        // Populate from saved configuration if exists
        viewModelScope.launch {
            repository.config.collect { savedConfig ->
                if (savedConfig != null) {
                    targetEye.value = savedConfig.targetEye
                    rightDropName.value = savedConfig.rightName
                    leftDropName.value = savedConfig.leftName
                    rightStartDate.value = savedConfig.rightStartDate.ifBlank { TimeUtils.todayIso() }
                    leftStartDate.value = savedConfig.leftStartDate.ifBlank { TimeUtils.todayIso() }
                    rightStartHour.value = savedConfig.rightStartHour
                    rightStartMin.value = savedConfig.rightStartMin
                    rightAmpm.value = savedConfig.rightAmpm
                    leftStartHour.value = savedConfig.leftStartHour
                    leftStartMin.value = savedConfig.leftStartMin
                    leftAmpm.value = savedConfig.leftAmpm
                    rightInterval.value = savedConfig.rightInterval
                    leftInterval.value = savedConfig.leftInterval
                    rightIsCustom.value = savedConfig.rightIsCustom
                    leftIsCustom.value = savedConfig.leftIsCustom
                    rightCustomHours.value = savedConfig.rightCustomH
                    rightCustomMins.value = savedConfig.rightCustomM
                    leftCustomHours.value = savedConfig.leftCustomH
                    leftCustomMins.value = savedConfig.leftCustomM
                }
            }
        }
    }

    fun setSelectedPage(page: Int) {
        _selectedPage.value = page
    }

    fun setRightSelectedDay(day: Int) {
        _rightSelectedDay.value = day
    }

    fun setLeftSelectedDay(day: Int) {
        _leftSelectedDay.value = day
    }

    fun toggleRightCollapse() {
        _rightCollapsed.value = !_rightCollapsed.value
    }

    fun toggleLeftCollapse() {
        _leftCollapsed.value = !_leftCollapsed.value
    }

    fun clearFeedbackMessage() {
        _userFeedbackMessage.value = null
    }

    fun fillWithToday() {
        val now = Calendar.getInstance()
        val today = TimeUtils.todayIso()
        val h24 = now.get(Calendar.HOUR_OF_DAY)
        val m = now.get(Calendar.MINUTE)
        val ampm = if (h24 >= 12) "PM" else "AM"
        val h12 = when (val h = h24 % 12) {
            0 -> 12
            else -> h
        }

        rightStartDate.value = today
        leftStartDate.value = today
        rightStartHour.value = h12
        rightStartMin.value = m
        rightAmpm.value = ampm
        leftStartHour.value = h12
        leftStartMin.value = m
        leftAmpm.value = ampm
    }

    fun generateSchedule(fallbackRightName: String, fallbackLeftName: String) {
        val rName = rightDropName.value.trim().ifEmpty { fallbackRightName }
        val lName = leftDropName.value.trim().ifEmpty { fallbackLeftName }

        val newConfig = ScheduleConfigEntity(
            id = 1,
            targetEye = targetEye.value,
            rightName = rName,
            leftName = lName,
            rightStartDate = rightStartDate.value,
            leftStartDate = leftStartDate.value,
            rightStartHour = rightStartHour.value,
            rightStartMin = rightStartMin.value,
            rightAmpm = rightAmpm.value,
            leftStartHour = leftStartHour.value,
            leftStartMin = leftStartMin.value,
            leftAmpm = leftAmpm.value,
            rightInterval = rightInterval.value,
            leftInterval = leftInterval.value,
            rightIsCustom = rightIsCustom.value,
            leftIsCustom = leftIsCustom.value,
            rightCustomH = rightCustomHours.value,
            rightCustomM = rightCustomMins.value,
            leftCustomH = leftCustomHours.value,
            leftCustomM = leftCustomMins.value
        )

        viewModelScope.launch {
            repository.generateAndSaveSchedule(newConfig)
            _selectedPage.value = 1 // Switch to Weekly Schedules tab immediately!
        }
    }

    fun saveCurrent() {
        viewModelScope.launch {
            val currentConfig = ScheduleConfigEntity(
                id = 1,
                targetEye = targetEye.value,
                rightName = rightDropName.value.trim(),
                leftName = leftDropName.value.trim(),
                rightStartDate = rightStartDate.value,
                leftStartDate = leftStartDate.value,
                rightStartHour = rightStartHour.value,
                rightStartMin = rightStartMin.value,
                rightAmpm = rightAmpm.value,
                leftStartHour = leftStartHour.value,
                leftStartMin = leftStartMin.value,
                leftAmpm = leftAmpm.value,
                rightInterval = rightInterval.value,
                leftInterval = leftInterval.value,
                rightIsCustom = rightIsCustom.value,
                leftIsCustom = leftIsCustom.value,
                rightCustomH = rightCustomHours.value,
                rightCustomM = rightCustomMins.value,
                leftCustomH = leftCustomHours.value,
                leftCustomM = leftCustomMins.value
            )
            repository.saveConfig(currentConfig)
            _userFeedbackMessage.value = "SAVED"
        }
    }

    fun toggleDose(dose: DoseEntity) {
        viewModelScope.launch {
            repository.toggleDose(dose.id, dose.isDone)
        }
    }

    fun clearAll() {
        viewModelScope.launch {
            repository.clearSchedule()
            _userFeedbackMessage.value = "CLEARED"
        }
    }
}
