package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF1B4D3E)
val EmeraldPrimaryDark = Color(0xFF14382C)
val EmeraldSecondary = Color(0xFF27AE60)
val EmeraldAccent = Color(0xFF2ECC71)
val EmeraldSoftBg = Color(0xFFF2F7F4)
val EmeraldCard = Color(0xFFFFFFFF)
val EmeraldText = Color(0xFF111B15)
val EmeraldMuted = Color(0xFF3D5A49)
val EmeraldBorder = Color(0x261B4D3E)
val EmeraldContainer = Color(0xFFE4EEE7)
val DangerRed = Color(0xFFC0392B)

// Dark Theme Colors
val DarkBg = Color(0xFF0B1410)
val DarkCard = Color(0xFF101E17)
val DarkText = Color(0xFFE4F2EB)
val DarkMuted = Color(0xFFA3C2B2)
val DarkBorder = Color(0x1FFFFFFF)
val DarkContainer = Color(0xFF162B21)
val DarkAccent = Color(0xFF2ECC71)
val DarkDanger = Color(0xFFFF8074)
