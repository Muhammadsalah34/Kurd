package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = DarkAccent,
    onPrimary = Color.Black,
    primaryContainer = DarkContainer,
    onPrimaryContainer = DarkText,
    secondary = EmeraldSecondary,
    onSecondary = Color.White,
    background = DarkBg,
    onBackground = DarkText,
    surface = DarkCard,
    onSurface = DarkText,
    surfaceVariant = DarkContainer,
    onSurfaceVariant = DarkMuted,
    outline = DarkBorder,
    error = DarkDanger,
    onError = Color.Black
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = EmeraldPrimaryDark,
    secondary = EmeraldSecondary,
    onSecondary = Color.White,
    background = EmeraldSoftBg,
    onBackground = EmeraldText,
    surface = EmeraldCard,
    onSurface = EmeraldText,
    surfaceVariant = EmeraldContainer,
    onSurfaceVariant = EmeraldMuted,
    outline = EmeraldBorder,
    error = DangerRed,
    onError = Color.White
)

@Composable
fun EyeDropTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
