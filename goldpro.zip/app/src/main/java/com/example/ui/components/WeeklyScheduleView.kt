package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DoseEntity
import com.example.data.ScheduleConfigEntity
import com.example.util.I18nManager
import com.example.util.PdfExporter
import com.example.util.TimeUtils

@Composable
fun WeeklyScheduleView(
    config: ScheduleConfigEntity?,
    doses: List<DoseEntity>,
    rightSelectedDay: Int,
    onRightDaySelect: (Int) -> Unit,
    leftSelectedDay: Int,
    onLeftDaySelect: (Int) -> Unit,
    rightCollapsed: Boolean,
    onToggleRightCollapse: () -> Unit,
    leftCollapsed: Boolean,
    onToggleLeftCollapse: () -> Unit,
    onToggleDose: (DoseEntity) -> Unit,
    onSave: () -> Unit,
    onClear: () -> Unit,
    lang: String,
    modifier: Modifier = Modifier
) {
    val i18n = I18nManager.getStrings(lang)
    val context = LocalContext.current
    val todayIso = TimeUtils.todayIso()

    val target = config?.targetEye ?: "both"
    val showRight = target == "right" || target == "both"
    val showLeft = target == "left" || target == "both"

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = i18n.week,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        if (doses.isEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = i18n.none,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Right Eye Card
            if (showRight) {
                SingleEyeScheduleCard(
                    eyeSide = "right",
                    eyeLabel = i18n.rightEyeLabel,
                    dropName = config?.rightName ?: i18n.rightEyeLabel,
                    intervalMinutes = if (config?.rightIsCustom == true) {
                        (config.rightCustomH * 60) + config.rightCustomM
                    } else {
                        config?.rightInterval ?: 240
                    },
                    selectedDayIndex = rightSelectedDay,
                    onDaySelect = onRightDaySelect,
                    isCollapsed = rightCollapsed,
                    onToggleCollapse = onToggleRightCollapse,
                    doses = doses.filter { it.eyeSide == "right" },
                    onToggleDose = onToggleDose,
                    todayIso = todayIso,
                    lang = lang,
                    onExportPdf = {
                        PdfExporter.exportScheduleToPdf(
                            context = context,
                            eyeSide = "right",
                            dropName = config?.rightName ?: "RightEyeDrop",
                            intervalMinutes = config?.rightInterval ?: 240,
                            doses = doses.filter { it.eyeSide == "right" },
                            lang = lang
                        )
                    }
                )
            }

            // Left Eye Card
            if (showLeft) {
                SingleEyeScheduleCard(
                    eyeSide = "left",
                    eyeLabel = i18n.leftEyeLabel,
                    dropName = config?.leftName ?: i18n.leftEyeLabel,
                    intervalMinutes = if (config?.leftIsCustom == true) {
                        (config.leftCustomH * 60) + config.leftCustomM
                    } else {
                        config?.leftInterval ?: 240
                    },
                    selectedDayIndex = leftSelectedDay,
                    onDaySelect = onLeftDaySelect,
                    isCollapsed = leftCollapsed,
                    onToggleCollapse = onToggleLeftCollapse,
                    doses = doses.filter { it.eyeSide == "left" },
                    onToggleDose = onToggleDose,
                    todayIso = todayIso,
                    lang = lang,
                    onExportPdf = {
                        PdfExporter.exportScheduleToPdf(
                            context = context,
                            eyeSide = "left",
                            dropName = config?.leftName ?: "LeftEyeDrop",
                            intervalMinutes = config?.leftInterval ?: 240,
                            doses = doses.filter { it.eyeSide == "left" },
                            lang = lang
                        )
                    }
                )
            }

            // Manage Actions (Save / Clear)
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onSave,
                    modifier = Modifier.weight(1f).testTag("schedule_save_btn"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = i18n.save,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(i18n.save, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onClear,
                    modifier = Modifier.weight(1f).testTag("schedule_clear_btn"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = i18n.clear,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(i18n.clear, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SingleEyeScheduleCard(
    eyeSide: String,
    eyeLabel: String,
    dropName: String,
    intervalMinutes: Int,
    selectedDayIndex: Int,
    onDaySelect: (Int) -> Unit,
    isCollapsed: Boolean,
    onToggleCollapse: () -> Unit,
    doses: List<DoseEntity>,
    onToggleDose: (DoseEntity) -> Unit,
    todayIso: String,
    lang: String,
    onExportPdf: () -> Unit
) {
    val i18n = I18nManager.getStrings(lang)
    val (selectedDayIso, _) = TimeUtils.getDayDateStr(todayIso, selectedDayIndex)
    val dayDoses = doses.filter { it.dateIso == selectedDayIso }

    Surface(
        modifier = Modifier.fillMaxWidth().testTag("${eyeSide}_schedule_card"),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "👁️ $eyeLabel",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // PDF Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable(onClick = onExportPdf)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("${eyeSide}_pdf_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = i18n.exportPdf,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = i18n.exportPdf,
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Collapse / Expand Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp))
                            .clickable(onClick = onToggleCollapse)
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                            .testTag("${eyeSide}_collapse_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = if (isCollapsed) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp,
                                contentDescription = i18n.collapse,
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = !isCollapsed,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Horizontal 7-Day tabs
                    val scrollState = rememberScrollState()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(scrollState),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (i in 0 until 7) {
                            val (dateIso, dayMonth) = TimeUtils.getDayDateStr(todayIso, i)
                            val dayOfWeek = TimeUtils.getDayOfWeekIndex(dateIso)
                            val dayName = i18n.days.getOrElse(dayOfWeek) { "" }
                            val isSelected = i == selectedDayIndex

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surface
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                        RoundedCornerShape(7.dp)
                                    )
                                    .clickable { onDaySelect(i) }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                                    .testTag("${eyeSide}_day_tab_$i"),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = dayName,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${dayMonth.first}/${dayMonth.second}",
                                        fontSize = 9.sp,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    // Day summary
                    val dayOfWeek = TimeUtils.getDayOfWeekIndex(selectedDayIso)
                    val dayName = i18n.days.getOrElse(dayOfWeek) { "" }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(dayName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(selectedDayIso, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    // Interval badge
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = i18n.intervalLabelText,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = TimeUtils.formatIntervalBadge(intervalMinutes, lang),
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Table Header
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(i18n.timeCol, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(75.dp), textAlign = TextAlign.Center)
                        Text(i18n.doseCol, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                        Text(i18n.statusCol, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(70.dp), textAlign = TextAlign.Center)
                    }

                    // Doses list
                    if (dayDoses.isEmpty()) {
                        Text(
                            text = "—",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(8.dp)
                        )
                    } else {
                        dayDoses.forEach { dose ->
                            DoseItemRow(
                                dose = dose,
                                eyeLabel = eyeLabel,
                                onToggle = { onToggleDose(dose) },
                                lang = lang
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DoseItemRow(
    dose: DoseEntity,
    eyeLabel: String,
    onToggle: () -> Unit,
    lang: String
) {
    val i18n = I18nManager.getStrings(lang)
    val timeFormatted = TimeUtils.formatTime12(dose.timestamp)

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (dose.isDone) MaterialTheme.colorScheme.surface.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Time
            Text(
                text = timeFormatted,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                modifier = Modifier.width(75.dp),
                textAlign = TextAlign.Center
            )

            // Dose Name & Eye Label
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = dose.dropName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textDecoration = if (dose.isDone) TextDecoration.LineThrough else TextDecoration.None
                )
                Text(
                    text = "💧 $eyeLabel",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Status Button
            Box(
                modifier = Modifier
                    .width(70.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (dose.isDone) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface
                    )
                    .border(
                        1.dp,
                        if (dose.isDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        RoundedCornerShape(6.dp)
                    )
                    .clickable(onClick = onToggle)
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (dose.isDone) "✓ ${i18n.done}" else "○ ${i18n.mark}",
                    color = if (dose.isDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    fontSize = 10.sp,
                    fontWeight = if (dose.isDone) FontWeight.ExtraBold else FontWeight.Normal,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
